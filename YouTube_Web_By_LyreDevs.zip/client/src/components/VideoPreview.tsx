import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { VideoInfo } from "@shared/schema";
import { Download, Check } from "lucide-react";

interface VideoPreviewProps {
  videoInfo: VideoInfo;
  url: string;
}

export default function VideoPreview({ videoInfo, url }: VideoPreviewProps) {
  const [selectedQuality, setSelectedQuality] = useState<string>();
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);

  // Sort available qualities from highest to lowest
  const availableQualities = videoInfo && videoInfo.formats && videoInfo.formats.length > 0 
    ? ["highest", ...new Set(videoInfo.formats
        .filter(format => format.quality)
        .map(f => f.quality))]
        .filter(q => q)
        .sort((a, b) => {
          if (a === "highest") return -1;
          if (b === "highest") return 1;
          const aNum = parseInt((a || "").replace('p', '')) || 0;
          const bNum = parseInt((b || "").replace('p', '')) || 0;
          return bNum - aNum;
        })
    : ["highest"];

  const handleDownload = () => {
    try {
      setIsDownloading(true);
      setDownloadComplete(false);
      const quality = selectedQuality || availableQualities[0];
      const downloadUrl = `/api/video/download?url=${encodeURIComponent(url)}&quality=${encodeURIComponent(quality)}`;

      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      document.body.appendChild(iframe);

      iframe.onload = () => {
        try {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
          if (iframeDoc?.body.textContent && iframeDoc.body.textContent.includes('{')) {
            const errorData = JSON.parse(iframeDoc.body.textContent);
            console.error('Download error:', errorData);
            alert(`Download failed: ${errorData.message || 'Unknown error'}`);
          } else {
            setDownloadComplete(true);
          }
          setTimeout(() => {
            document.body.removeChild(iframe);
            setIsDownloading(false);
          }, 1000);
        } catch (e) {
          setDownloadComplete(true);
          setTimeout(() => {
            document.body.removeChild(iframe);
            setIsDownloading(false);
          }, 1000);
        }
      };

      iframe.src = downloadUrl;
    } catch (error) {
      console.error('Error initiating download:', error);
      setIsDownloading(false);
      alert('Failed to start download. Please try again.');
    }
  };

  return (
    <Card className="w-full overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardContent className="p-4 sm:p-6">
        <div className="grid md:grid-cols-[1fr_2fr] gap-6">
          <div className="flex flex-col items-center space-y-4">
            <div className="relative w-full aspect-video rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:scale-105">
              <img 
                src={videoInfo.thumbnail} 
                alt={videoInfo.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/10" />
            </div>
            <div className="w-full space-y-3">
              <Select 
                value={selectedQuality || availableQualities[0]} 
                onValueChange={setSelectedQuality}
              >
                <SelectTrigger className="w-full h-12">
                  <SelectValue placeholder="Select quality" />
                </SelectTrigger>
                <SelectContent>
                  {availableQualities.map((quality) => (
                    <SelectItem key={quality} value={quality} className="cursor-pointer">
                      {quality === 'highest' ? 'Highest Quality' : quality}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button 
                className="w-full h-12 text-base font-medium transition-all duration-200 hover:scale-105"
                onClick={handleDownload}
                disabled={isDownloading}
              >
                {isDownloading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current mr-2" />
                    Downloading...
                  </>
                ) : downloadComplete ? (
                  <>
                    <Check className="mr-2 h-5 w-5" />
                    Downloaded
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-5 w-5" />
                    Download
                  </>
                )}
              </Button>
            </div>
          </div>
          <div className="flex flex-col">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 line-clamp-2 text-card-foreground">
              {videoInfo.title}
            </h2>
            <div className="text-muted-foreground mb-4 text-sm sm:text-base">
              {availableQualities.length} quality options available
            </div>
            <div className="space-y-3">
              <p className="text-sm font-medium text-card-foreground">Available Qualities:</p>
              <div className="flex flex-wrap gap-2">
                {availableQualities.map((quality) => (
                  <div 
                    key={quality}
                    className="px-3 py-1.5 bg-primary/10 text-primary rounded-full text-xs font-medium transition-colors duration-200 hover:bg-primary/20"
                  >
                    {quality === 'highest' ? 'Highest Quality' : quality}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}