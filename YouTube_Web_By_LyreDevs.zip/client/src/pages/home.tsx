import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { VideoInfo, videoUrlSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import VideoPreview from "@/components/VideoPreview";
import Footer from "@/components/Footer";
import { Youtube } from "lucide-react";

export default function Home() {
  const { toast } = useToast();
  const [videoUrl, setVideoUrl] = useState<string>();

  const form = useForm({
    resolver: zodResolver(videoUrlSchema),
    defaultValues: {
      url: "",
    },
  });

  const { data: videoInfo, isLoading, refetch } = useQuery<VideoInfo>({
    queryKey: ["videoInfo", videoUrl],
    queryFn: async () => {
      if (!videoUrl) throw new Error("No URL provided");
      try {
        const response = await fetch("/api/video/info", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: videoUrl })
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.message || "Failed to get video info");
        }

        return await response.json();
      } catch (error) {
        console.error("Error fetching video info:", error);
        throw error;
      }
    },
    enabled: !!videoUrl,
  });

  const getInfo = useMutation({
    mutationFn: async (values: { url: string }) => {
      setVideoUrl(values.url);
      return values;
    },
    onSuccess: () => {
      refetch();
      toast({
        title: "Success!",
        description: "Getting video information...",
        className: "bg-primary text-primary-foreground",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to get video info",
      });
    },
  });

  const onSubmit = form.handleSubmit((data) => {
    getInfo.mutate(data);
  });

  return (
    <div className="min-h-screen bg-background flex flex-col transition-colors duration-300">
      <main className="flex-1 container max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="text-center mb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-4 flex items-center justify-center gap-3">
            <Youtube className="h-8 w-8 animate-pulse" />
            LyreMusic YouTube Downloader
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm sm:text-base">
            Download YouTube videos in your preferred quality. Fast, simple, and ad-free!
          </p>
        </div>

        <Card className="mb-8 shadow-lg animate-in fade-in slide-in-from-bottom-4 duration-500 delay-150">
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={onSubmit} className="space-y-4">
                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Input
                            placeholder="Paste YouTube URL here..."
                            {...field}
                            className="flex-1 h-12 text-base"
                          />
                          <Button 
                            type="submit"
                            disabled={getInfo.isPending}
                            className="h-12 px-8 text-base font-medium transition-all duration-200 hover:scale-105"
                          >
                            {getInfo.isPending ? (
                              <>
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current mr-2" />
                                Loading...
                              </>
                            ) : "Get Info"}
                          </Button>
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />
              </form>
            </Form>
          </CardContent>
        </Card>

        {isLoading && (
          <div className="text-center py-12 animate-in fade-in slide-in-from-bottom-4">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent mx-auto mb-4" />
            <p className="text-muted-foreground">Fetching video information...</p>
          </div>
        )}

        {videoInfo && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <VideoPreview videoInfo={videoInfo} url={videoUrl!} />
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}