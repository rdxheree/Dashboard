import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, Github, Youtube, Code, ExternalLink } from "lucide-react";
import Footer from "@/components/Footer";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Hero Section */}
      <main className="flex-1">
        <section className="py-12 sm:py-20 md:py-32 container relative">
          <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_80%_80%_at_50%_50%,#000_70%,transparent_100%)]"></div>
          <div className="text-center space-y-4 sm:space-y-6 max-w-3xl mx-auto px-4">
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60 animate-in fade-in slide-in-from-bottom-4 duration-700 tracking-tight">
              LyreMusic Downloader
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200 max-w-2xl mx-auto px-4 sm:px-6">
              A modern, fast, and beautiful YouTube video downloader built with cutting-edge technology.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-300">
              <Link href="/youtube">
                <Button size="lg" className="w-full sm:w-auto h-12 px-8 font-medium gap-2 hover:scale-105 transition-transform">
                  <Youtube className="w-5 h-5" />
                  Start Downloading
                </Button>
              </Link>
              <a href="https://github.com/rdxheree" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" size="lg" className="w-full sm:w-auto h-12 px-8 font-medium gap-2">
                  <Github className="w-5 h-5" />
                  View Source
                </Button>
              </a>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 sm:py-20 bg-muted/50">
          <div className="container px-4 sm:px-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-center mb-8 sm:mb-12">Features</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              <Card className="transform transition-all duration-300 hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <Download className="w-12 h-12 text-primary" />
                    <h3 className="text-xl font-semibold">Multiple Qualities</h3>
                    <p className="text-muted-foreground">Download videos in various qualities, from 360p to 4K.</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="transform transition-all duration-300 hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <Code className="w-12 h-12 text-primary" />
                    <h3 className="text-xl font-semibold">Modern Tech Stack</h3>
                    <p className="text-muted-foreground">Built with React, TypeScript, and Node.js for reliable performance.</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="transform transition-all duration-300 hover:scale-105 sm:col-span-2 lg:col-span-1">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <ExternalLink className="w-12 h-12 text-primary" />
                    <h3 className="text-xl font-semibold">Open Source</h3>
                    <p className="text-muted-foreground">Free to use and open source. Contribute on GitHub.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Developer Section */}
        <section className="py-16 sm:py-20">
          <div className="container px-4 sm:px-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-center mb-8 sm:mb-12">About the Developer</h2>
            <Card className="max-w-2xl mx-auto transform transition-all duration-300 hover:shadow-xl">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center transform transition-all duration-300 hover:scale-110">
                    <Code className="w-12 h-12 text-primary" />
                  </div>
                  <h3 className="text-2xl font-semibold">RdxHere</h3>
                  <p className="text-muted-foreground max-w-lg mx-auto">
                    Full-stack developer passionate about creating beautiful and functional web applications.
                    Specialized in React, TypeScript, and Node.js development.
                  </p>
                  <div className="flex gap-4 pt-4">
                    <a 
                      href="https://github.com/rdxheree"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-primary transition-colors transform hover:scale-110"
                    >
                      <Github className="w-6 h-6" />
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}