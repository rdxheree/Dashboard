// Using the default storage.ts since we don't need persistence
export const storage = new MemStorage();
