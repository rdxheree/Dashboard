import type { Express } from "express";
import { createServer } from "http";
import ytdl from "@distube/ytdl-core";
import { Agent } from "https";
import { videoUrlSchema, type VideoInfo, VIDEO_QUALITIES } from "@shared/schema";
import http from "http";
import https from "https";

// Create a custom HTTPS agent with keepAlive
const agent = new http.Agent({
  keepAlive: true,
  maxSockets: 25,
  maxFreeSockets: 10,
  timeout: 120000, // 2 minutes
});

const secureAgent = new https.Agent({
  keepAlive: true,
  maxSockets: 25,
  maxFreeSockets: 10,
  timeout: 120000, // 2 minutes
});

// Helper function to get the appropriate agent based on the URL
const getAgent = (url: string) => {
  return url.startsWith('https:') ? secureAgent : agent;
};

export async function registerRoutes(app: Express) {
  app.post("/api/video/info", async (req, res) => {
    try {
      const { url } = videoUrlSchema.parse(req.body);

      if (!ytdl.validateURL(url)) {
        return res.status(400).json({ message: "Invalid YouTube URL" });
      }

      const info = await ytdl.getInfo(url);

      // Get available formats
      const formats = info.formats.filter(format => 
        format.hasVideo && 
        format.qualityLabel && 
        VIDEO_QUALITIES.includes(format.qualityLabel as any)
      );

      const videoInfo: VideoInfo = {
        title: info.videoDetails.title,
        thumbnail: info.videoDetails.thumbnails[0].url,
        formats: formats.map(format => ({
          quality: format.qualityLabel || '',
          url: format.url,
          container: format.container || 'mp4'
        }))
      };

      res.json(videoInfo);
    } catch (error) {
      console.error('Video info error:', error);
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to get video info" });
      }
    }
  });

  app.get("/api/video/download", async (req, res) => {
    try {
      const { url, quality } = req.query;

      if (!url || typeof url !== "string") {
        return res.status(400).json({ message: "URL is required" });
      }

      if (!ytdl.validateURL(url)) {
        return res.status(400).json({ message: "Invalid YouTube URL" });
      }

      const info = await ytdl.getInfo(url);

      // Try to get the best format matching the requested quality
      let format;
      try {
        if (quality === 'highest') {
          // Choose formats with both audio and video
          format = ytdl.chooseFormat(info.formats, { quality: 'highest' });
        } else {
          // Find format with matching quality label and has audio
          format = info.formats.find(f => f.qualityLabel === quality && f.hasVideo && f.hasAudio);
          if (!format) {
            // If no format with the requested quality has audio, choose a format with both audio and video
            format = ytdl.chooseFormat(info.formats, { quality: 'highest' });
          }
        }
      } catch (error) {
        // Fallback to highest quality with audio if specific quality not available
        format = ytdl.chooseFormat(info.formats, { quality: 'highest' });
      }

      // Sanitize the filename
      const fileName = `${info.videoDetails.title.replace(/[^a-z0-9]/gi, '_')}.mp4`;
      
      // Set proper headers for file download
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Type', 'video/mp4');
      
      // Create stream with proper error handling, ensuring audio is included
      const stream = ytdl(url as string, { 
        format,
        filter: 'audioandvideo', // Ensure we get formats with both audio and video
        quality: quality === 'highest' ? 'highest' : undefined
      });
      
      // Handle stream errors
      stream.on('error', (err) => {
        console.error('Stream error:', err);
        if (!res.headersSent) {
          res.status(500).json({ message: 'Error during video streaming' });
        }
      });

      // Pipe the stream to response
      stream.pipe(res);

    } catch (error) {
      console.error('Download error:', error);
      if (!res.headersSent) {
        if (error instanceof Error) {
          res.status(400).json({ message: error.message });
        } else {
          res.status(500).json({ message: "Failed to download video" });
        }
      }
    }
  });

  return createServer(app);
}