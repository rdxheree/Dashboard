import { z } from "zod";

export const videoUrlSchema = z.object({
  url: z.string().url().refine((url) => {
    return url.includes("youtube.com/") || url.includes("youtu.be/");
  }, "Must be a valid YouTube URL"),
});

export type VideoUrl = z.infer<typeof videoUrlSchema>;

export interface VideoInfo {
  title: string;
  thumbnail: string;
  formats: VideoFormat[];
}

export interface VideoFormat {
  quality: string;
  url: string;
  container: string;
}

export const VIDEO_QUALITIES = ["144p", "240p", "360p", "480p", "720p"] as const;
